<?php
error_reporting(1);
$con=mysqli_connect('localhost', 'root', '','poll') or die(mysqli_error());

?>
